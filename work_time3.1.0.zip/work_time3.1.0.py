import sys
import csv
import datetime
import os
import re
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.dates as mdates
from matplotlib.ticker import MaxNLocator
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QTreeWidget, QTreeWidgetItem, QFrame,
                             QDateEdit, QScrollArea, QLineEdit, QCheckBox, QFileDialog,
                             QMessageBox, QGraphicsDropShadowEffect, QSizePolicy, QHeaderView,
                             QDialog, QSpinBox, QComboBox, QGridLayout, QGroupBox, QTabWidget)
from PyQt6.QtCore import (Qt, QPropertyAnimation, QEasingCurve, QDate, QSize,
                          pyqtProperty, QTimer, QPoint, QRect, QThread, pyqtSignal)
from PyQt6.QtGui import (QColor, QPainter, QPainterPath, QLinearGradient, QFont,
                         QPalette, QIcon, QPixmap, QBrush)
import urllib.request
import tempfile
import hashlib
import zipfile
import shutil
from pathlib import Path
import matplotlib
matplotlib.use('Qt5Agg')

# --- Константы ---
DATE_FORMAT_INTERNAL = "%Y-%m-%d"
DATE_FORMAT_DISPLAY = "%d-%m-%Y"
TIME_FORMAT = "%H:%M"
DATETIME_FORMAT_DISPLAY = "%d.%m.%Y"
CURRENT_VERSION = "3.1.0"

# URL для проверки обновлений (замените на ваш реальный URL)
UPDATE_CHECK_URL = "https://your-server.com/worktime-tracker/version.json"
# Или используйте сетевую папку:
# UPDATE_CHECK_URL = "file:///Z:/shared/worktime-tracker/version.json"

# Определяем правильный путь к приложению (для EXE-режима)
def get_application_path():
    """Возвращает путь к постоянному хранилищу для EXE или скрипта"""
    if getattr(sys, 'frozen', False):
        # Если запущено как EXE
        return os.path.dirname(sys.executable)
    else:
        # Если запущено как скрипт
        return os.path.dirname(os.path.abspath(__file__))

# Устанавливаем пути к файлам
APP_PATH = get_application_path()
CONFIG_DIR = os.path.join(APP_PATH, "config")
CONFIG_FILE = os.path.join(CONFIG_DIR, "app_config.json")
DEFAULT_FILENAME = os.path.join(APP_PATH, "work_time.csv")
DEFAULT_TOTALS_FILE = os.path.join(APP_PATH, "work_time_totals.csv")

# Создаем папку для конфига если не существует
os.makedirs(CONFIG_DIR, exist_ok=True)

# --- Конфигурация ---
def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # Убедимся, что все необходимые параметры присутствуют
                config.setdefault("file_path", DEFAULT_FILENAME)
                config.setdefault("totals_file_path", DEFAULT_TOTALS_FILE)
                config.setdefault("update_check_url", UPDATE_CHECK_URL)
                config.setdefault("auto_check_updates", True)
                return config
        except Exception as e:
            print(f"Ошибка загрузки конфигурации: {e}")
    # Создаем новый конфиг с правильными путями
    config = {
        "file_path": DEFAULT_FILENAME,
        "totals_file_path": DEFAULT_TOTALS_FILE,
        "update_check_url": UPDATE_CHECK_URL,
        "auto_check_updates": True
    }
    save_config(config)
    return config

def save_config(config):
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        print(f"Ошибка сохранения конфига: {e}")
        return False

# --- Стиль приложения ---
APP_DARK = "#0A1428"
APP_DARK_BLUE = "#0E1A2B"
APP_LIGHT_BLUE = "#CDFAFA"
APP_GOLD = "#C8AA6E"
APP_GOLD_LIGHT = "#F0E6D2"
APP_RED = "#FF4454"
APP_GREEN = "#00CC99"

# --- Система обновлений ---
class UpdateChecker(QThread):
    update_available = pyqtSignal(dict)
    check_completed = pyqtSignal()
    error_occurred = pyqtSignal(str)
    
    def __init__(self, check_url, current_version):
        super().__init__()
        self.check_url = check_url
        self.current_version = current_version
    
    def run(self):
        try:
            if self.check_url.startswith('file://'):
                # Локальный файл (сетевая папка)
                local_path = self.check_url[7:]  # Убираем 'file://'
                if os.path.exists(local_path):
                    with open(local_path, 'r', encoding='utf-8') as f:
                        update_info = json.load(f)
                else:
                    self.error_occurred.emit(f"Файл обновления не найден: {local_path}")
                    return
            else:
                # URL в интернете
                with urllib.request.urlopen(self.check_url) as response:
                    update_info = json.loads(response.read().decode('utf-8'))
            
            # Проверяем версию
            if self.is_newer_version(update_info['version']):
                self.update_available.emit(update_info)
            else:
                self.check_completed.emit()
                
        except Exception as e:
            self.error_occurred.emit(f"Ошибка при проверке обновлений: {str(e)}")
    
    def is_newer_version(self, new_version):
        """Сравнивает версии и возвращает True если новая версия новее"""
        def parse_version(version):
            return [int(x) for x in version.split('.')]
        
        current_parts = parse_version(self.current_version)
        new_parts = parse_version(new_version)
        
        return new_parts > current_parts

class UpdateManager(QThread):
    progress_updated = pyqtSignal(int, str)
    update_finished = pyqtSignal(bool, str)
    
    def __init__(self, update_info, app_path):
        super().__init__()
        self.update_info = update_info
        self.app_path = app_path
    
    def run(self):
        try:
            self.progress_updated.emit(0, "Начало загрузки обновления...")
            
            # Создаем временную папку для загрузки
            temp_dir = tempfile.mkdtemp()
            download_path = os.path.join(temp_dir, "update.zip")
            
            # Загружаем обновление
            if self.update_info['download_url'].startswith('file://'):
                # Локальный файл
                local_path = self.update_info['download_url'][7:]
                shutil.copy2(local_path, download_path)
            else:
                # URL в интернете
                self.download_file(self.update_info['download_url'], download_path)
            
            self.progress_updated.emit(50, "Загрузка завершена, проверка целостности...")
            
            # Проверяем хеш файла (если указан)
            if 'file_hash' in self.update_info:
                if not self.verify_file_hash(download_path, self.update_info['file_hash']):
                    raise Exception("Хеш файла не совпадает. Файл может быть поврежден.")
            
            self.progress_updated.emit(70, "Распаковка обновления...")
            
            # Распаковываем обновление
            self.extract_update(download_path, temp_dir)
            
            self.progress_updated.emit(90, "Установка обновления...")
            
            # Устанавливаем обновление
            self.install_update(temp_dir)
            
            # Очищаем временные файлы
            shutil.rmtree(temp_dir)
            
            self.progress_updated.emit(100, "Обновление завершено!")
            self.update_finished.emit(True, "Обновление успешно установлено!")
            
        except Exception as e:
            self.update_finished.emit(False, f"Ошибка при обновлении: {str(e)}")
    
    def download_file(self, url, dest_path):
        """Загружает файл с прогрессом"""
        def progress_callback(block_num, block_size, total_size):
            if total_size > 0:
                percent = min(100, int((block_num * block_size * 50) / total_size))
                self.progress_updated.emit(percent, f"Загрузка: {percent}%")
        
        urllib.request.urlretrieve(url, dest_path, progress_callback)
    
    def verify_file_hash(self, file_path, expected_hash):
        """Проверяет хеш файла"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest() == expected_hash
    
    def extract_update(self, zip_path, extract_dir):
        """Распаковывает архив с обновлением"""
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
    
    def install_update(self, update_dir):
        """Устанавливает обновление"""
        # Ищем файлы в распакованной папке
        for root, dirs, files in os.walk(update_dir):
            for file in files:
                if file.endswith('.exe') or file.endswith('.dll') or file.endswith('.py'):
                    src_path = os.path.join(root, file)
                    dest_path = os.path.join(self.app_path, file)
                    
                    # Создаем директорию если нужно
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    
                    # Копируем файл
                    shutil.copy2(src_path, dest_path)

class UpdateDialog(QDialog):
    def __init__(self, update_info, parent=None):
        super().__init__(parent)
        self.update_info = update_info
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle("Доступно обновление")
        self.setFixedSize(500, 400)
        self.setStyleSheet(f"background-color: {APP_DARK};")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Заголовок
        title = QLabel("Доступно новое обновление!")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 18px;
            font-weight: bold;
        """)
        layout.addWidget(title)
        
        # Информация о версии
        version_info = QLabel(f"Текущая версия: {CURRENT_VERSION} → Новая версия: {self.update_info['version']}")
        version_info.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
        layout.addWidget(version_info)
        
        # Описание изменений
        changes_label = QLabel("Что нового в этой версии:")
        changes_label.setStyleSheet(f"color: {APP_GOLD}; font-weight: bold;")
        layout.addWidget(changes_label)
        
        changes_text = QLabel(self.update_info.get('changelog', 'Нет информации об изменениях'))
        changes_text.setWordWrap(True)
        changes_text.setStyleSheet(f"""
            color: {APP_LIGHT_BLUE};
            background-color: {APP_DARK_BLUE};
            padding: 10px;
            border-radius: 5px;
            border: 1px solid {APP_GOLD};
        """)
        changes_text.setMinimumHeight(150)
        layout.addWidget(changes_text)
        
        # Размер обновления
        if 'size' in self.update_info:
            size_label = QLabel(f"Размер обновления: {self.update_info['size']}")
            size_label.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
            layout.addWidget(size_label)
        
        # Кнопки
        button_layout = QHBoxLayout()
        
        update_now_btn = RoundedButton("Обновить сейчас")
        update_now_btn.clicked.connect(self.accept)
        button_layout.addWidget(update_now_btn)
        
        later_btn = RoundedButton("Напомнить позже")
        later_btn.clicked.connect(self.reject)
        button_layout.addWidget(later_btn)
        
        skip_btn = RoundedButton("Пропустить эту версию")
        skip_btn.clicked.connect(self.skip_version)
        button_layout.addWidget(skip_btn)
        
        layout.addLayout(button_layout)
    
    def skip_version(self):
        # Можно добавить логику для пропуска этой версии
        self.reject()

class UpdateProgressDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        self.setWindowTitle("Обновление приложения")
        self.setFixedSize(400, 200)
        self.setStyleSheet(f"background-color: {APP_DARK};")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        self.status_label = QLabel("Подготовка к обновлению...")
        self.status_label.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
        layout.addWidget(self.status_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid {APP_GOLD};
                border-radius: 5px;
                text-align: center;
                background-color: {APP_DARK_BLUE};
            }}
            QProgressBar::chunk {{
                background-color: {APP_GOLD};
            }}
        """)
        layout.addWidget(self.progress_bar)
        
        cancel_btn = RoundedButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        layout.addWidget(cancel_btn)
    
    def update_progress(self, percent, status):
        self.progress_bar.setValue(percent)
        self.status_label.setText(status)

class WorkerThread(QThread):
    finished = pyqtSignal()
    error = pyqtSignal(str)
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
    def run(self):
        try:
            self.func(*self.args, **self.kwargs)
            self.finished.emit()
        except Exception as e:
            self.error.emit(str(e))

class RoundedButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._animation = QPropertyAnimation(self, b"geometry")
        self._animation.setDuration(200)
        # Настройка стиля
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 2px solid {APP_GOLD};
                border-radius: 15px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {APP_GOLD};
                color: {APP_DARK};
            }}
            QPushButton:pressed {{
                background-color: {APP_GOLD_LIGHT};
            }}
        """)
    def mousePressEvent(self, event):
        # Анимация нажатия
        self._animation.stop()
        self._animation.setStartValue(self.geometry())
        self._animation.setEndValue(QRect(self.x(), self.y() + 2, self.width(), self.height()))
        self._animation.setEasingCurve(QEasingCurve.Type.OutQuad)
        self._animation.start()
        super().mousePressEvent(event)
    def mouseReleaseEvent(self, event):
        # Анимация отпускания
        self._animation.stop()
        self._animation.setStartValue(self.geometry())
        self._animation.setEndValue(QRect(self.x(), self.y() - 2, self.width(), self.height()))
        self._animation.setEasingCurve(QEasingCurve.Type.OutQuad)
        self._animation.start()
        super().mouseReleaseEvent(event)

class GlassWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Создание эффекта матового стекла
        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 15, 15)
        # Градиент для фона
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(APP_DARK_BLUE).lighter(120))
        gradient.setColorAt(1, QColor(APP_DARK_BLUE).darker(120))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(gradient))
        painter.drawPath(path)
        # Бордер
        painter.setPen(QColor(APP_GOLD))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(0, 0, self.width() - 1, self.height() - 1, 15, 15)

class EditDialog(QDialog):
    def __init__(self, values, parent=None):
        super().__init__(parent)
        self.values = values
        self.setup_ui()
    def setup_ui(self):
        self.setWindowTitle("Редактирование записи")
        self.setFixedSize(350, 300)
        self.setStyleSheet(f"background-color: {APP_DARK};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        # Дата
        date_label = QLabel("Дата (ДД-ММ-ГГГГ):")
        date_label.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
        layout.addWidget(date_label)
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd-MM-yyyy")  # Исправленный формат
        self.date_edit.setStyleSheet(f"""
            QDateEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        layout.addWidget(self.date_edit)
        # Время
        time_label = QLabel("Время (ЧЧ:ММ):")
        time_label.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
        layout.addWidget(time_label)
        time_frame = QWidget()
        time_layout = QHBoxLayout(time_frame)
        time_layout.setContentsMargins(0, 0, 0, 0)
        self.hours_spin = QSpinBox()
        self.hours_spin.setRange(0, 23)
        self.hours_spin.setStyleSheet(f"""
            QSpinBox {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        time_layout.addWidget(self.hours_spin)
        time_layout.addWidget(QLabel(":"))
        self.minutes_spin = QSpinBox()
        self.minutes_spin.setRange(0, 59)
        self.minutes_spin.setStyleSheet(f"""
            QSpinBox {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        time_layout.addWidget(self.minutes_spin)
        time_layout.addStretch()
        layout.addWidget(time_frame)
        # Событие
        event_label = QLabel("Событие:")
        event_label.setStyleSheet(f"color: {APP_LIGHT_BLUE};")
        layout.addWidget(event_label)
        self.event_combo = QComboBox()
        self.event_combo.addItems(["приход", "уход"])
        self.event_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        layout.addWidget(self.event_combo)
        # Кнопки
        button_layout = QHBoxLayout()
        save_btn = RoundedButton("Сохранить")
        save_btn.clicked.connect(self.accept)
        button_layout.addWidget(save_btn)
        cancel_btn = RoundedButton("Отмена")
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)
        # Установка текущих значений
        self.set_values()
    def set_values(self):
        if len(self.values) >= 4:
            # Установка даты
            try:
                date_str = self.values[1]  # Дата в формате ДД-ММ-ГГГГ
                date = QDate.fromString(date_str, "dd-MM-yyyy")
                if date.isValid():
                    self.date_edit.setDate(date)
                else:
                    self.date_edit.setDate(QDate.currentDate())
            except:
                self.date_edit.setDate(QDate.currentDate())
            # Установка времени
            try:
                time_parts = self.values[2].split(':')
                if len(time_parts) == 2:
                    self.hours_spin.setValue(int(time_parts[0]))
                    self.minutes_spin.setValue(int(time_parts[1]))
            except:
                pass
            # Установка события
            self.event_combo.setCurrentText(self.values[3])
    def get_values(self):
        date = self.date_edit.date().toString("dd-MM-yyyy")  # Исправленный формат
        time = f"{self.hours_spin.value():02d}:{self.minutes_spin.value():02d}"
        event = self.event_combo.currentText()
        return [self.values[0], date, time, event]

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # Загрузка конфигурации
        self.config = load_config()
        self.FILENAME = self.config["file_path"]
        self.TOTALS_FILE = self.config["totals_file_path"]
        # Кэш данных
        self._raw_data_cache = None
        self._data_changed = True # Изначально данные нужно загрузить
        self.setWindowTitle("WorkTime Tracker")
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        # Центральный виджет
        central_widget = QWidget()
        central_widget.setStyleSheet(f"background-color: {APP_DARK};")
        self.setCentralWidget(central_widget)
        # Основной layout
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        # Боковая панель навигации
        self.setup_navigation(main_layout)
        # Основная область контента
        self.setup_content_area(main_layout)
        # Инициализация UI
        self.init_ui()
        # Таймер для обновления статуса
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(60000)  # Обновление каждую минуту
        # Worker thread
        self.worker = None
        
        # Система обновлений
        self.update_checker = None
        self.update_manager = None
        self.update_progress_dialog = None
        
        # Проверяем обновления при запуске (если включено в настройках)
        if self.config.get("auto_check_updates", True):
            QTimer.singleShot(3000, self.check_for_updates)  # Проверка через 3 секунды после запуска

    def check_for_updates(self):
        """Проверяет наличие обновлений"""
        update_url = self.config.get("update_check_url", UPDATE_CHECK_URL)
        if not update_url:
            return
            
        self.update_checker = UpdateChecker(update_url, CURRENT_VERSION)
        self.update_checker.update_available.connect(self.on_update_available)
        self.update_checker.check_completed.connect(self.on_update_check_completed)
        self.update_checker.error_occurred.connect(self.on_update_error)
        self.update_checker.start()
        
    def on_update_available(self, update_info):
        """Вызывается когда найдено обновление"""
        dialog = UpdateDialog(update_info, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.start_update(update_info)
    
    def on_update_check_completed(self):
        """Вызывается когда проверка завершена и обновлений нет"""
        # Можно показать сообщение, но обычно это не нужно
        pass
    
    def on_update_error(self, error_message):
        """Вызывается при ошибке проверки обновлений"""
        # Логируем ошибку, но не показываем пользователю чтобы не беспокоить
        print(f"Ошибка проверки обновлений: {error_message}")
    
    def start_update(self, update_info):
        """Начинает процесс обновления"""
        self.update_progress_dialog = UpdateProgressDialog(self)
        self.update_progress_dialog.show()
        
        self.update_manager = UpdateManager(update_info, APP_PATH)
        self.update_manager.progress_updated.connect(self.update_progress_dialog.update_progress)
        self.update_manager.update_finished.connect(self.on_update_finished)
        self.update_manager.start()
    
    def on_update_finished(self, success, message):
        """Вызывается когда обновление завершено"""
        if self.update_progress_dialog:
            self.update_progress_dialog.close()
            
        if success:
            QMessageBox.information(self, "Обновление завершено", 
                                  f"{message}\nПриложение будет перезапущено.")
            self.restart_application()
        else:
            QMessageBox.warning(self, "Ошибка обновления", message)
    
    def restart_application(self):
        """Перезапускает приложение"""
        QApplication.quit()
        # Запускаем приложение заново
        if getattr(sys, 'frozen', False):
            # В режиме EXE
            os.execl(sys.executable, sys.executable, *sys.argv)
        else:
            # В режиме скрипта
            os.execl(sys.executable, sys.executable, *sys.argv)

    def invalidate_data_cache(self):
        """Сбрасывает кэш данных."""
        self._data_changed = True
        self._raw_data_cache = None

    def get_raw_data(self):
        """Возвращает сырые данные из файла, используя кэш."""
        if not self._data_changed and self._raw_data_cache is not None:
            return self._raw_data_cache
        raw_data = []
        if os.path.exists(self.FILENAME):
            try:
                # Используем только utf-8-sig
                with open(self.FILENAME, 'r', newline='', encoding='utf-8-sig') as f:
                    reader = csv.reader(f)
                    headers = next(reader, None)  # Пропускаем заголовок
                    for row in reader:
                        # Пропускаем пустые строки
                        if not row:
                            continue
                        # Попробуем распарсить дату в двух форматах
                        date_str = row[0]
                        # Попробуем DD-MM-YYYY
                        try:
                            parsed_date = datetime.datetime.strptime(date_str, "%d-%m-%Y").strftime("%Y-%m-%d")
                            row[0] = parsed_date  # Заменяем на правильный формат
                        except ValueError:
                            # Попробуем YYYY-MM-DD
                            try:
                                parsed_date = datetime.datetime.strptime(date_str, "%Y-%m-%d").strftime("%Y-%m-%d")
                                row[0] = parsed_date
                            except ValueError:
                                print(f"Не удалось распознать дату: {date_str}")
                                continue
                        # Сохраняем только строки с данными
                        if len(row) >= 3:
                            raw_data.append(row)
            except UnicodeDecodeError as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка декодирования файла: {e}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка",
                                     f"Не удалось прочитать файл. Детали: {e}")
        self._raw_data_cache = raw_data
        self._data_changed = False
        return raw_data

    def check_status(self):
        """Определяет текущий статус рабочего дня"""
        today = datetime.date.today().strftime(DATE_FORMAT_INTERNAL)
        last_event_type = None
        raw_data = self.get_raw_data()
        # Ищем последнее событие за сегодня
        for row in reversed(raw_data):
            if row[0] == today:
                last_event_type = row[2]
                break
        # Если последнее событие - уход или нет событий, следующее будет приход
        if last_event_type is None or last_event_type == "уход":
            return "start"
        else:
            return "end"

    def validate_event_sequence(self, date, time, event_type):
        """Проверяет корректность последовательности событий"""
        raw_data = self.get_raw_data()
        today_events = [row for row in raw_data if row[0] == date]
        if not today_events:
            return event_type == "приход"
        last_event = today_events[-1]
        # Нельзя два прихода или два ухода подряд
        if last_event[2] == event_type:
            return False
        # Проверяем что время нового события не раньше последнего
        try:
            last_time = datetime.datetime.strptime(last_event[1], TIME_FORMAT)
            new_time = datetime.datetime.strptime(time, TIME_FORMAT)
            return new_time >= last_time
        except:
            return True

    def calculate_durations(self):
        """Рассчитывает продолжительность рабочих интервалов"""
        daily_intervals = {}
        raw_data = self.get_raw_data()
        # Группируем события по датам
        events_by_date = {}
        for row in raw_data:
            date, time, event_type = row[0], row[1], row[2]
            if date not in events_by_date:
                events_by_date[date] = []
            events_by_date[date].append((time, event_type))
        # Обрабатываем каждую дату
        for date, events in events_by_date.items():
            daily_intervals[date] = []
            i = 0
            while i < len(events) - 1:
                time1, event1 = events[i]
                time2, event2 = events[i + 1]
                if event1 == "приход" and event2 == "уход":
                    # Рассчитываем продолжительность
                    try:
                        start_dt = datetime.datetime.strptime(time1, TIME_FORMAT)
                        end_dt = datetime.datetime.strptime(time2, TIME_FORMAT)
                        # Учитываем переход через полночь
                        if end_dt < start_dt:
                            end_dt += datetime.timedelta(days=1)
                        duration = end_dt - start_dt
                        hours = duration.total_seconds() // 3600
                        minutes = (duration.total_seconds() % 3600) // 60
                        daily_intervals[date].append((time1, time2, f"{int(hours)}:{int(minutes):02d}"))
                        i += 2  # Пропускаем пару событий
                    except Exception as e:
                        print(f"Ошибка при расчете времени: {e}")
                        i += 1
                else:
                    i += 1
        return daily_intervals

    def save_totals(self):
        """Сохраняет итоги в отдельный файл"""
        # Получаем все интервалы
        daily_intervals = self.calculate_durations()
        # Рассчитываем итоги по дням
        daily_totals = {}
        for date, intervals in daily_intervals.items():
            total_minutes = 0
            for _, _, duration in intervals:
                try:
                    h, m = map(int, duration.split(':'))
                    total_minutes += h * 60 + m
                except:
                    continue
            hours = total_minutes // 60
            minutes = total_minutes % 60
            daily_totals[date] = f"{int(hours)}:{int(minutes):02d}"
        # Рассчитываем общий итог
        grand_total_minutes = 0
        for total in daily_totals.values():
            try:
                h, m = map(int, total.split(':'))
                grand_total_minutes += h * 60 + m
            except:
                continue
        grand_hours = grand_total_minutes // 60
        grand_minutes = grand_total_minutes % 60
        grand_total = f"{int(grand_hours)}:{int(grand_minutes):02d}"
        # Сохраняем итоги в отдельный файл
        try:
            with open(self.TOTALS_FILE, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter=',')
                # Заголовки итогов
                writer.writerow(["Дата", "Приход", "Уход", "Продолжительность"])
                # Детализация по интервалам
                for date, intervals in daily_intervals.items():
                    for start, end, duration in intervals:
                        writer.writerow([date, start, end, duration])
                # Итоги по дням
                writer.writerow([])
                writer.writerow(["Итоги по дням", "", "", ""])
                for date, total in daily_totals.items():
                    writer.writerow([date, "", "", total])
                # Общий итог
                writer.writerow([])
                writer.writerow(["Общий итог", "", "", grand_total])
        except Exception as e:
            # Не показываем QMessageBox в потоке
            print(f"Ошибка сохранения итогов: {e}")
            raise # Передаем ошибку в сигнал error потока

    def log_time(self):
        """Фиксирует время прихода/ухода"""
        status = self.check_status()
        now = datetime.datetime.now().strftime(TIME_FORMAT)
        today = datetime.date.today().strftime(DATE_FORMAT_INTERNAL)
        # Определяем тип события
        event_type = "приход" if status == "start" else "уход"
        # Проверяем корректность последовательности событий
        if not self.validate_event_sequence(today, now, event_type):
            QMessageBox.critical(self, "Ошибка", "Некорректная последовательность событий!")
            return
        # Создаем файл если не существует
        if not os.path.exists(self.FILENAME):
            with open(self.FILENAME, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter=',')
                writer.writerow(["Дата", "Время", "Тип события"])
        # Добавляем новое событие
        try:
            with open(self.FILENAME, 'a', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter=',')
                row_data = [today, now, event_type]
                writer.writerow(row_data)
            self.invalidate_data_cache() # Сбросить кэш после добавления
            # Сохраняем итоги в отдельном потоке
            if self.worker and self.worker.isRunning():
                 QMessageBox.warning(self, "Предупреждение", "Сохранение итогов уже выполняется.")
                 return
            self.worker = WorkerThread(self.save_totals)
            self.worker.finished.connect(self.update_after_log)
            self.worker.error.connect(lambda err: QMessageBox.critical(self, "Ошибка", f"Ошибка при сохранении итогов: {err}"))
            self.worker.start()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить данные: {e}")

    def update_after_log(self):
        """Обновляет интерфейс после записи события"""
        new_status = self.check_status()
        self.update_button(new_status)
        self.update_title()
        # Обновляем статистику и редактирование, если они открыты
        if self.current_screen == "statistics":
            self.load_statistics_data()
        elif self.current_screen == "edit":
            self.load_edit_data()

    def setup_navigation(self, main_layout):
        # Панель навигации
        nav_frame = GlassWidget()
        nav_layout = QVBoxLayout(nav_frame)
        nav_layout.setContentsMargins(15, 15, 15, 15)
        nav_layout.setSpacing(10)
        # Заголовок
        title = QLabel("WorkTime Tracker")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 18px;
            font-weight: bold;
            padding: 10px;
            background-color: transparent;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        nav_layout.addWidget(title)
        # Кнопки навигации
        nav_buttons = [
            ("Главная", self.show_main),
            ("Импорт", self.show_import),  # Новая кнопка импорта
            ("Статистика", self.show_stats),
            ("Редактирование", self.show_edit),
            ("Настройки", self.show_settings),
        ]
        self.nav_buttons = []
        for text, slot in nav_buttons:
            btn = RoundedButton(text)
            btn.clicked.connect(slot)
            btn.setFixedHeight(45)
            nav_layout.addWidget(btn)
            self.nav_buttons.append(btn)
        nav_layout.addStretch()
        # Кнопка выхода
        exit_btn = RoundedButton("Выход")
        exit_btn.clicked.connect(self.close)
        exit_btn.setFixedHeight(45)
        exit_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {APP_RED};
                color: {APP_DARK};
                border: 2px solid {APP_RED};
                border-radius: 15px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: #FF6677;
                border-color: #FF6677;
            }}
        """)
        nav_layout.addWidget(exit_btn)
        main_layout.addWidget(nav_frame, 1)

    def setup_content_area(self, main_layout):
        # Основная область контента
        content_frame = GlassWidget()
        content_layout = QVBoxLayout(content_frame)
        content_layout.setContentsMargins(20, 20, 20, 20)
        content_layout.setSpacing(15)
        # Контентная область
        self.content_stack = QTabWidget()
        self.content_stack.setDocumentMode(True)
        self.content_stack.tabBar().setVisible(False)
        self.content_stack.setStyleSheet(f"""
            QTabWidget::pane {{
                border: 0;
                background: transparent;
            }}
        """)
        # Создание экранов
        self.setup_main_screen()
        self.setup_import_screen()  # Новый экран импорта
        self.setup_stats_screen()
        self.setup_edit_screen()
        self.setup_settings_screen()
        content_layout.addWidget(self.content_stack)
        main_layout.addWidget(content_frame, 3)
        # Инициализируем текущий экран
        self.current_screen = "main"

    def setup_main_screen(self):
        main_screen = QWidget()
        layout = QVBoxLayout(main_screen)
        # Заголовок
        title = QLabel("Учёт рабочего времени")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 24px;
            font-weight: bold;
            padding: 10px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        # Кнопка основного действия
        self.main_action_btn = QPushButton("НАЧАТЬ РАБОЧИЙ ДЕНЬ")
        self.main_action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.main_action_btn.setFixedHeight(80)
        self.main_action_btn.clicked.connect(self.log_time)
        self.main_action_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {APP_GREEN};
                color: {APP_DARK};
                font-size: 16px;
                font-weight: bold;
                border-radius: 20px;
                border: 2px solid {APP_GREEN};
                padding: 15px;
            }}
            QPushButton:hover {{
                background-color: #00FFAA;
                border-color: #00FFAA;
            }}
            QPushButton:pressed {{
                background-color: #00AA77;
                border-color: #00AA77;
            }}
        """)
        layout.addWidget(self.main_action_btn)
        # Статус
        self.status_label = QLabel("Готов к работе")
        self.status_label.setStyleSheet(f"color: {APP_LIGHT_BLUE}; font-size: 14px;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status_label)
        layout.addStretch()
        self.content_stack.addTab(main_screen, "main")

    def setup_import_screen(self):
        """Настройка экрана импорта данных"""
        import_screen = QWidget()
        layout = QVBoxLayout(import_screen)
        # Заголовок импорта
        title = QLabel("Импорт данных в Excel")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 24px;
            font-weight: bold;
            padding: 10px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        # Выбор периода
        period_frame = QWidget()
        period_layout = QHBoxLayout(period_frame)
        period_layout.setContentsMargins(0, 0, 0, 0)
        period_layout.addWidget(QLabel("С:"))
        self.import_start_date = QDateEdit()
        self.import_start_date.setCalendarPopup(True)
        self.import_start_date.setDate(QDate.currentDate().addDays(-7))
        self.import_start_date.setDisplayFormat("dd-MM-yyyy")  # Исправленный формат
        self.import_start_date.setStyleSheet(f"""
            QDateEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        period_layout.addWidget(self.import_start_date)
        period_layout.addWidget(QLabel("По:"))
        self.import_end_date = QDateEdit()
        self.import_end_date.setCalendarPopup(True)
        self.import_end_date.setDate(QDate.currentDate())
        self.import_end_date.setDisplayFormat("dd-MM-yyyy")  # Исправленный формат
        self.import_end_date.setStyleSheet(f"""
            QDateEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        period_layout.addWidget(self.import_end_date)
        import_btn = RoundedButton("Экспорт в Excel")
        import_btn.clicked.connect(self.export_to_excel)
        period_layout.addWidget(import_btn)
        period_layout.addStretch()
        layout.addWidget(period_frame)
        layout.addStretch()
        self.content_stack.addTab(import_screen, "import")

    def setup_stats_screen(self):
        stats_screen = QWidget()
        layout = QVBoxLayout(stats_screen)
        # Заголовок статистики
        title = QLabel("Статистика рабочего времени")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 24px;
            font-weight: bold;
            padding: 10px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        # Выбор период
        period_frame = QWidget()
        period_layout = QHBoxLayout(period_frame)
        period_layout.setContentsMargins(0, 0, 0, 0)
        period_layout.addWidget(QLabel("С:"))
        self.stats_start_date = QDateEdit()
        self.stats_start_date.setCalendarPopup(True)
        self.stats_start_date.setDate(QDate.currentDate().addDays(-7))
        self.stats_start_date.setDisplayFormat("dd-MM-yyyy")  # Исправленный формат
        self.stats_start_date.setStyleSheet(f"""
            QDateEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        period_layout.addWidget(self.stats_start_date)
        period_layout.addWidget(QLabel("По:"))
        self.stats_end_date = QDateEdit()
        self.stats_end_date.setCalendarPopup(True)
        self.stats_end_date.setDate(QDate.currentDate())
        self.stats_end_date.setDisplayFormat("dd-MM-yyyy")  # Исправленный формат
        self.stats_end_date.setStyleSheet(f"""
            QDateEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        period_layout.addWidget(self.stats_end_date)
        apply_btn = RoundedButton("Применить")
        apply_btn.clicked.connect(self.load_statistics_data)
        period_layout.addWidget(apply_btn)
        period_layout.addStretch()
        layout.addWidget(period_frame)
        # Таблица с данными
        self.stats_tree = QTreeWidget()
        self.stats_tree.setHeaderLabels(["Дата", "Время", "Событие"])
        self.stats_tree.setStyleSheet(f"""
            QTreeWidget {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 10px;
                alternate-background-color: {APP_DARK};
            }}
            QTreeWidget::item {{
                padding: 5px;
                border-bottom: 1px solid {APP_GOLD};
            }}
            QTreeWidget::item:selected {{
                background-color: {APP_GOLD};
                color: {APP_DARK};
            }}
            QHeaderView::section {{
                background-color: {APP_DARK_BLUE};
                color: {APP_GOLD};
                font-weight: bold;
                padding: 5px;
                border: 0;
            }}
        """)
        self.stats_tree.setAlternatingRowColors(True)
        self.stats_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.stats_tree)
        # График
        self.figure, self.ax = plt.subplots(figsize=(10, 6))
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setStyleSheet(f"background-color: {APP_DARK_BLUE}; border: 1px solid {APP_GOLD}; border-radius: 10px;")
        layout.addWidget(self.canvas)
        # УДАЛЕНО: Кнопки "Показать график" и "Сохранить график"
        self.content_stack.addTab(stats_screen, "stats")

    def setup_edit_screen(self):
        edit_screen = QWidget()
        layout = QVBoxLayout(edit_screen)
        # Заголовок редактирования
        title = QLabel("Редактирование данных")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 24px;
            font-weight: bold;
            padding: 10px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        # Таблица с данными
        self.edit_tree = QTreeWidget()
        self.edit_tree.setHeaderLabels(["ID", "Дата", "Время", "Событие"]) # ID теперь это дата
        self.edit_tree.setStyleSheet(f"""
            QTreeWidget {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 10px;
                alternate-background-color: {APP_DARK};
            }}
            QTreeWidget::item {{
                padding: 5px;
                border-bottom: 1px solid {APP_GOLD};
            }}
            QTreeWidget::item:selected {{
                background-color: {APP_GOLD};
                color: {APP_DARK};
            }}
            QHeaderView::section {{
                background-color: {APP_DARK_BLUE};
                color: {APP_GOLD};
                font-weight: bold;
                padding: 5px;
                border: 0;
            }}
        """)
        self.edit_tree.setAlternatingRowColors(True)
        self.edit_tree.header().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.edit_tree)
        # Кнопки управления
        btn_frame = QWidget()
        btn_layout = QHBoxLayout(btn_frame)
        btn_layout.setContentsMargins(0, 0, 0, 0)
        edit_btn = RoundedButton("Редактировать")
        edit_btn.clicked.connect(self.edit_selected)
        btn_layout.addWidget(edit_btn)
        delete_btn = RoundedButton("Удалить")
        delete_btn.clicked.connect(self.delete_edit_selected)
        btn_layout.addWidget(delete_btn)
        self.save_edit_btn = RoundedButton("Сохранить изменения")
        self.save_edit_btn.clicked.connect(self.save_edit_changes)
        btn_layout.addWidget(self.save_edit_btn)
        btn_layout.addStretch()
        layout.addWidget(btn_frame)
        self.content_stack.addTab(edit_screen, "edit")

    def setup_settings_screen(self):
        settings_screen = QWidget()
        layout = QVBoxLayout(settings_screen)
        # Заголовок настроек
        title = QLabel("Настройки приложения")
        title.setStyleSheet(f"""
            color: {APP_GOLD};
            font-size: 24px;
            font-weight: bold;
            padding: 10px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        # Настройки
        settings_group = QGroupBox("Основные настройки")
        settings_group.setStyleSheet(f"""
            QGroupBox {{
                color: {APP_GOLD};
                font-weight: bold;
                font-size: 16px;
                border: 2px solid {APP_GOLD};
                border-radius: 10px;
                margin-top: 1ex;
                padding-top: 10px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }}
        """)
        settings_layout = QVBoxLayout(settings_group)
        # Файл данных
        file_layout = QHBoxLayout()
        file_layout.addWidget(QLabel("Файл данных:"))
        self.settings_file_path = QLineEdit(self.config["file_path"])
        self.settings_file_path.setStyleSheet(f"""
            QLineEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        file_layout.addWidget(self.settings_file_path)
        file_browse_btn = RoundedButton("Обзор")
        file_browse_btn.clicked.connect(self.browse_data_file)
        file_layout.addWidget(file_browse_btn)
        settings_layout.addLayout(file_layout)
        # Файл итогов
        totals_layout = QHBoxLayout()
        totals_layout.addWidget(QLabel("Файл итогов:"))
        self.settings_totals_path = QLineEdit(self.config["totals_file_path"])
        self.settings_totals_path.setStyleSheet(f"""
            QLineEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        totals_layout.addWidget(self.settings_totals_path)
        totals_browse_btn = RoundedButton("Обзор")
        totals_browse_btn.clicked.connect(self.browse_totals_file)
        totals_layout.addWidget(totals_browse_btn)
        settings_layout.addLayout(totals_layout)
        
        # Настройки обновлений
        updates_group = QGroupBox("Настройки обновлений")
        updates_group.setStyleSheet(f"""
            QGroupBox {{
                color: {APP_GOLD};
                font-weight: bold;
                font-size: 16px;
                border: 2px solid {APP_GOLD};
                border-radius: 10px;
                margin-top: 1ex;
                padding-top: 10px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }}
        """)
        updates_layout = QVBoxLayout(updates_group)
        
        # URL для проверки обновлений
        update_url_layout = QHBoxLayout()
        update_url_layout.addWidget(QLabel("URL обновлений:"))
        self.settings_update_url = QLineEdit(self.config.get("update_check_url", UPDATE_CHECK_URL))
        self.settings_update_url.setStyleSheet(f"""
            QLineEdit {{
                background-color: {APP_DARK_BLUE};
                color: {APP_LIGHT_BLUE};
                border: 1px solid {APP_GOLD};
                border-radius: 5px;
                padding: 5px;
            }}
        """)
        update_url_layout.addWidget(self.settings_update_url)
        updates_layout.addLayout(update_url_layout)
        
        # Автопроверка обновлений
        self.auto_update_check = QCheckBox("Автоматически проверять обновления при запуске")
        self.auto_update_check.setChecked(self.config.get("auto_check_updates", True))
        self.auto_update_check.setStyleSheet(f"""
            QCheckBox {{
                color: {APP_LIGHT_BLUE};
                spacing: 5px;
            }}
            QCheckBox::indicator {{
                width: 15px;
                height: 15px;
            }}
            QCheckBox::indicator:unchecked {{
                border: 1px solid {APP_GOLD};
                background-color: {APP_DARK_BLUE};
            }}
            QCheckBox::indicator:checked {{
                border: 1px solid {APP_GOLD};
                background-color: {APP_GOLD};
            }}
        """)
        updates_layout.addWidget(self.auto_update_check)
        
        # Кнопка проверки обновлений
        check_updates_btn = RoundedButton("Проверить обновления сейчас")
        check_updates_btn.clicked.connect(self.check_for_updates)
        updates_layout.addWidget(check_updates_btn)
        
        # Информация о версии
        version_layout = QHBoxLayout()
        version_layout.addWidget(QLabel(f"Текущая версия: {CURRENT_VERSION}"))
        version_layout.addStretch()
        updates_layout.addLayout(version_layout)
        
        settings_layout.addWidget(updates_group)
        layout.addWidget(settings_group)
        
        # Кнопка сохранения
        save_btn = RoundedButton("Сохранить настройки")
        save_btn.clicked.connect(self.save_settings)
        save_btn.setFixedHeight(50)
        layout.addWidget(save_btn)
        layout.addStretch()
        self.content_stack.addTab(settings_screen, "settings")

    def browse_data_file(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Выберите файл для сохранения данных",
            self.settings_file_path.text(),
            "CSV files (*.csv);;All files (*.*)"
        )
        if path:
            self.settings_file_path.setText(path)

    def browse_totals_file(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Выберите файл для сохранения итогов",
            self.settings_totals_path.text(),
            "CSV files (*.csv);;All files (*.*)"
        )
        if path:
            self.settings_totals_path.setText(path)

    def save_settings(self):
        """Сохраняет настройки"""
        new_path = self.settings_file_path.text()
        new_totals_path = self.settings_totals_path.text()
        # Проверяем пути
        if not new_path or not new_totals_path:
            QMessageBox.critical(self, "Ошибка", "Пути к файлам не могут быть пустыми")
            return
        # Проверяем права записи
        try:
            if not os.path.exists(new_path):
                with open(new_path, 'w', newline='', encoding='utf-8-sig') as f:
                    pass
            if not os.path.exists(new_totals_path):
                with open(new_totals_path, 'w', newline='', encoding='utf-8-sig') as f:
                    pass
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Нет прав на запись в выбранные папки: {e}")
            return
        # Сохраняем настройки
        self.config["file_path"] = new_path
        self.config["totals_file_path"] = new_totals_path
        self.config["update_check_url"] = self.settings_update_url.text()
        self.config["auto_check_updates"] = self.auto_update_check.isChecked()
        if save_config(self.config):
            # Обновляем глобальные переменные
            self.FILENAME = new_path
            self.TOTALS_FILE = new_totals_path
            self.invalidate_data_cache() # Сбросить кэш после изменения пути
            QMessageBox.information(self, "Успех", "Настройки сохранены")
            self.update_button(self.check_status())
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось сохранить настройки")

    def init_ui(self):
        # Инициализация UI
        self.show_main()
        self.update_status()

    def show_main(self):
        self.content_stack.setCurrentIndex(0)
        self.current_screen = "main"
        self.update_nav_buttons(0)

    def show_import(self):
        self.content_stack.setCurrentIndex(1)
        self.current_screen = "import"
        self.update_nav_buttons(1)

    def show_stats(self):
        self.content_stack.setCurrentIndex(2)
        self.current_screen = "statistics"
        self.load_statistics_data()
        self.update_nav_buttons(2)

    def show_edit(self):
        self.content_stack.setCurrentIndex(3)
        self.current_screen = "edit"
        self.load_edit_data()
        self.update_nav_buttons(3)

    def show_settings(self):
        self.content_stack.setCurrentIndex(4)
        self.current_screen = "settings"
        self.update_nav_buttons(4)

    def update_nav_buttons(self, index):
        # Сбрасываем стили всех кнопок
        for btn in self.nav_buttons:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {APP_DARK_BLUE};
                    color: {APP_LIGHT_BLUE};
                    border: 2px solid {APP_GOLD};
                    border-radius: 15px;
                    padding: 10px 20px;
                    font-weight: bold;
                    font-size: 12px;
                }}
                QPushButton:hover {{
                    background-color: {APP_GOLD};
                    color: {APP_DARK};
                }}
            """)
        # Устанавливаем стиль для активной кнопки
        if 0 <= index < len(self.nav_buttons):
            self.nav_buttons[index].setStyleSheet(f"""
                QPushButton {{
                    background-color: {APP_GOLD};
                    color: {APP_DARK};
                    border: 2px solid {APP_GOLD};
                    border-radius: 15px;
                    padding: 10px 20px;
                    font-weight: bold;
                    font-size: 12px;
                }}
            """)

    def load_statistics_data(self):
        """Загружает данные в экран статистики"""
        # Очищаем таблицу
        self.stats_tree.clear()
        # Загружаем данные
        raw_data = self.get_raw_data()
        start = self.stats_start_date.date().toString("yyyy-MM-dd")
        end = self.stats_end_date.date().toString("yyyy-MM-dd")
        for row in raw_data:
            try:
                row_date = datetime.datetime.strptime(row[0], DATE_FORMAT_INTERNAL).date()
                start_date = datetime.datetime.strptime(start, DATE_FORMAT_INTERNAL).date()
                end_date = datetime.datetime.strptime(end, DATE_FORMAT_INTERNAL).date()
                if start_date <= row_date <= end_date:
                    # Форматируем дату для отображения
                    formatted_date = row_date.strftime(DATE_FORMAT_DISPLAY)
                    item = QTreeWidgetItem(self.stats_tree, [formatted_date, row[1], row[2]])
            except Exception as e:
                print(f"Ошибка при загрузке статистики: {e}")
                continue
        # Обновляем график
        self.show_chart()

    def load_edit_data(self):
        """Загружает данные в экран редактирования"""
        # Очищаем таблицу
        self.edit_tree.clear()
        # Загружаем данные
        raw_data = self.get_raw_data()
        for i, row in enumerate(raw_data):
            # Используем дату как ID
            item_id = row[0]
            # Форматируем дату для отображения
            try:
                formatted_date = datetime.datetime.strptime(row[0], DATE_FORMAT_INTERNAL).strftime(DATE_FORMAT_DISPLAY)
                item = QTreeWidgetItem(self.edit_tree, [item_id, formatted_date, row[1], row[2]])
            except:
                # Если дата не распознана, показываем как есть
                item = QTreeWidgetItem(self.edit_tree, [item_id, row[0], row[1], row[2]])

    def show_chart(self):
        """Показывает график рабочего времени"""
        raw_data = self.get_raw_data()
        start = self.stats_start_date.date().toString("yyyy-MM-dd")
        end = self.stats_end_date.date().toString("yyyy-MM-dd")
        # Группируем данные по дням
        daily_totals = {}
        daily_intervals = self.calculate_durations()
        for date, intervals in daily_intervals.items():
            try:
                row_date = datetime.datetime.strptime(date, DATE_FORMAT_INTERNAL).date()
                start_date = datetime.datetime.strptime(start, DATE_FORMAT_INTERNAL).date()
                end_date = datetime.datetime.strptime(end, DATE_FORMAT_INTERNAL).date()
                if start_date <= row_date <= end_date:
                    total_minutes = 0
                    for _, _, duration in intervals:
                        h, m = map(int, duration.split(':'))
                        total_minutes += h * 60 + m
                    hours = total_minutes / 60
                    daily_totals[date] = hours
            except Exception as e:
                print(f"Ошибка при подготовке данных для графика: {e}")
                continue
        if not daily_totals:
            # QMessageBox.information(self, "Информация", "Нет данных за выбранный период")
            # Очищаем график, если нет данных
            self.ax.clear()
            self.canvas.draw()
            return
        # Создаем график
        self.ax.clear()
        # Настройка стиля графика
        plt.style.use('dark_background')
        self.figure.patch.set_facecolor(APP_DARK)
        self.ax.set_facecolor(APP_DARK_BLUE)
        
        # Установка цветов для всех элементов графика
        self.ax.spines['bottom'].set_color(APP_LIGHT_BLUE)
        self.ax.spines['left'].set_color(APP_LIGHT_BLUE)
        self.ax.spines['top'].set_color(APP_LIGHT_BLUE)
        self.ax.spines['right'].set_color(APP_LIGHT_BLUE)
        self.ax.tick_params(colors=APP_LIGHT_BLUE)
        self.ax.xaxis.label.set_color(APP_LIGHT_BLUE)
        self.ax.yaxis.label.set_color(APP_LIGHT_BLUE)
        self.ax.title.set_color(APP_GOLD)
        
        dates = [datetime.datetime.strptime(d, DATE_FORMAT_INTERNAL) for d in daily_totals.keys()]
        values = list(daily_totals.values())
        # Создаем столбчатую диаграмму
        bars = self.ax.bar(dates, values, color=APP_GOLD, alpha=0.8, edgecolor=APP_GOLD, linewidth=2)
        # Форматируем оси
        self.ax.xaxis.set_major_formatter(mdates.DateFormatter(DATE_FORMAT_DISPLAY))
        self.ax.xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(dates)//10)))
        plt.setp(self.ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
        # Устанавливаем целые числа на оси Y
        self.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        # Добавляем сетку
        self.ax.grid(True, alpha=0.3, linestyle='--', color=APP_LIGHT_BLUE)
        # Добавляем подписи значений над столбцами
        for i, v in enumerate(values):
            self.ax.text(dates[i], v + 0.1, f'{v:.1f}', ha='center', va='bottom', fontweight='bold', color=APP_GOLD)
        self.ax.set_xlabel("Дата", fontsize=12, color=APP_LIGHT_BLUE)
        self.ax.set_ylabel("Часы", fontsize=12, color=APP_LIGHT_BLUE)
        self.ax.set_title("Рабочее время по дням", fontsize=14, color=APP_GOLD, fontweight='bold')
        # Настраиваем цвет меток
        self.ax.tick_params(colors=APP_LIGHT_BLUE)
        # Обновляем canvas
        self.canvas.draw()

    def save_chart(self):
        """Сохраняет график в файл"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить график", "", "PNG files (*.png);;All files (*.*)"
        )
        if file_path:
            self.figure.savefig(file_path, dpi=300, bbox_inches='tight', facecolor=APP_DARK)
            QMessageBox.information(self, "Успех", "График сохранен успешно")

    def save_edit_changes(self):
        """Сохраняет изменения в файл"""
        # Собираем все данные из таблицы
        all_data = []
        for i in range(self.edit_tree.topLevelItemCount()):
            item = self.edit_tree.topLevelItem(i)
            values = [item.text(j) for j in range(item.columnCount())]
            # Пропускаем ID (values[0]) и используем дату из UI (values[1])
            if len(values) >= 4:
                # Конвертируем дату из UI обратно в формат YYYY-MM-DD
                date_str = values[1] # Дата из UI
                try:
                    date_obj = datetime.datetime.strptime(date_str, DATE_FORMAT_DISPLAY)
                    formatted_date = date_obj.strftime(DATE_FORMAT_INTERNAL)
                    all_data.append([formatted_date, values[2], values[3]])
                except Exception as e:
                     print(f"Ошибка при конвертации даты при сохранении: {e}")
                     # Если не удалось конвертировать, используем как есть
                     all_data.append([values[1], values[2], values[3]])
        # Сохраняем в файл
        try:
            with open(self.FILENAME, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter=',')
                writer.writerow(["Дата", "Время", "Тип события"])
                for row in all_data:
                    writer.writerow(row)
            self.invalidate_data_cache() # Сбросить кэш после сохранения
            # Пересчитываем итоги
            if self.worker and self.worker.isRunning():
                 QMessageBox.warning(self, "Предупреждение", "Сохранение итогов уже выполняется.")
                 return
            self.save_edit_btn.setEnabled(False) # Отключить кнопку во время сохранения
            self.worker = WorkerThread(self.save_totals)
            self.worker.finished.connect(lambda: [self.save_edit_btn.setEnabled(True), self.on_edit_save_finished()])
            self.worker.error.connect(lambda err: [self.save_edit_btn.setEnabled(True), QMessageBox.critical(self, "Ошибка", f"Ошибка при сохранении итогов: {err}")])
            self.worker.start()
        except Exception as e:
            self.save_edit_btn.setEnabled(True)
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить данные: {e}")

    def on_edit_save_finished(self):
        """Вызывается после завершения сохранения изменений из редактора."""
        # Обновляем статистику, если она открыта
        if self.current_screen == "statistics":
            self.load_statistics_data()
        QMessageBox.information(self, "Успех", "Изменения сохранены")

    def delete_edit_selected(self):
        """Удаляет выбранную запись"""
        selected = self.edit_tree.selectedItems()
        if not selected:
            QMessageBox.warning(self, "Внимание", "Выберите запись для удаления")
            return
        if QMessageBox.question(self, "Подтверждение", "Удалить выбранную запись?") == QMessageBox.StandardButton.Yes:
            for item in selected:
                index = self.edit_tree.indexOfTopLevelItem(item)
                self.edit_tree.takeTopLevelItem(index)
            # Автоматически сохраняем изменения после удаления
            self.save_edit_changes()

    def edit_selected(self):
        """Редактирует выбранную запись"""
        selected = self.edit_tree.selectedItems()
        if not selected or len(selected) > 1:
            QMessageBox.warning(self, "Внимание", "Выберите одну запись для редактирования")
            return
        item = selected[0]
        values = [item.text(i) for i in range(item.columnCount())]
        # Создаем диалоговое окно редактирования
        dialog = EditDialog(values, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_values = dialog.get_values()
            # Обновляем запись в таблице
            for i in range(len(new_values)):
                item.setText(i, new_values[i])
            # Сохраняем изменения
            self.save_edit_changes()

    def export_to_excel(self):
        """Экспортирует данные за выбранный период в CSV файл для Excel"""
        start_date = self.import_start_date.date().toString("yyyy-MM-dd")
        end_date = self.import_end_date.date().toString("yyyy-MM-dd")
        # Получаем интервалы по дням
        daily_intervals = self.calculate_durations()
        # Фильтруем по выбранному периоду
        filtered_intervals = {}
        for date, intervals in daily_intervals.items():
            try:
                row_date = datetime.datetime.strptime(date, DATE_FORMAT_INTERNAL).date()
                start = datetime.datetime.strptime(start_date, DATE_FORMAT_INTERNAL).date()
                end = datetime.datetime.strptime(end_date, DATE_FORMAT_INTERNAL).date()
                if start <= row_date <= end:
                    filtered_intervals[date] = intervals
            except Exception as e:
                print(f"Ошибка при фильтрации данных для экспорта: {e}")
                continue
        if not filtered_intervals:
            QMessageBox.information(self, "Информация", "Нет данных за выбранный период")
            return
        # Запрашиваем путь для сохранения файла
        default_filename = f"work_time_export_{datetime.date.today().strftime('%Y-%m-%d')}.csv"
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить данные для Excel",
            default_filename,
            "CSV files (*.csv);;All files (*.*)"
        )
        if not file_path:
            return
        try:
            with open(file_path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter='|')
                writer.writerow(["Дата", "Время"])
                # Для каждой даты вычисляем общее время работы в формате 5,5 (5 часов 30 минут)
                for date, intervals in filtered_intervals.items():
                    total_minutes = 0
                    for _, _, duration in intervals:
                        try:
                            h, m = map(int, duration.split(':'))
                            total_minutes += h * 60 + m
                        except:
                            continue
                    # Преобразуем в десятичный формат (5 часов 30 минут = 5.5)
                    total_hours = total_minutes / 60
                    # Форматируем дату для отображения
                    formatted_date = datetime.datetime.strptime(date, DATE_FORMAT_INTERNAL).strftime(DATE_FORMAT_DISPLAY)
                    # Записываем данные в формате "Дата|время"
                    writer.writerow([formatted_date, f"{total_hours:.1f}".replace('.', ',')])
            QMessageBox.information(self, "Успех", f"Данные успешно экспортированы в файл:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось экспортировать данные: {e}")

    def update_status(self):
        """Обновляет статус приложения"""
        status = self.check_status()
        self.update_button(status)
        self.update_title()
        # Проверяем наличие данных
        if os.path.exists(self.FILENAME) and os.path.getsize(self.FILENAME) > 0:
            self.status_label.setText(f"Данные загружены. Готов к работе (файл: {os.path.basename(self.FILENAME)})")
        else:
            self.status_label.setText("Новый файл создан. Начните рабочий день")

    def update_button(self, status):
        if status == "start":
            self.main_action_btn.setText("НАЧАТЬ РАБОЧИЙ ДЕНЬ")
            self.main_action_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {APP_GREEN};
                    color: {APP_DARK};
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 20px;
                    border: 2px solid {APP_GREEN};
                    padding: 15px;
                }}
                QPushButton:hover {{
                    background-color: #00FFAA;
                    border-color: #00FFAA;
                }}
                QPushButton:pressed {{
                    background-color: #00AA77;
                    border-color: #00AA77;
                }}
            """)
        else:
            self.main_action_btn.setText("ЗАВЕРШИТЬ РАБОЧИЙ ДЕНЬ")
            self.main_action_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {APP_RED};
                    color: {APP_DARK};
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 20px;
                    border: 2px solid {APP_RED};
                    padding: 15px;
                }}
                QPushButton:hover {{
                    background-color: #FF6677;
                    border-color: #FF6677;
                }}
                QPushButton:pressed {{
                    background-color: #CC4455;
                    border-color: #CC4455;
                }}
            """)

    def update_title(self):
        """Обновляет заголовок окна с текущим статусом"""
        status = self.check_status()
        today = datetime.date.today().strftime(DATETIME_FORMAT_DISPLAY)
        if status == "start":
            self.setWindowTitle(f"WorkTime Tracker - {today} (ожидание прихода)")
        else:
            self.setWindowTitle(f"WorkTime Tracker - {today} (ожидание ухода)")

    def mousePressEvent(self, event):
        # Перемещение окна
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_start_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        # Перемещение окна
        if event.buttons() == Qt.MouseButton.LeftButton and hasattr(self, 'drag_start_position'):
            self.move(event.globalPosition().toPoint() - self.drag_start_position)
            event.accept()

# Запуск приложения
if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Установка стиля приложения
    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(APP_DARK))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(APP_LIGHT_BLUE))
    palette.setColor(QPalette.ColorRole.Base, QColor(APP_DARK_BLUE))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(APP_DARK))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(APP_GOLD))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor(APP_DARK))
    palette.setColor(QPalette.ColorRole.Text, QColor(APP_LIGHT_BLUE))
    palette.setColor(QPalette.ColorRole.Button, QColor(APP_DARK_BLUE))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(APP_LIGHT_BLUE))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(APP_GOLD))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor(APP_DARK))
    app.setPalette(palette)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())